# ⚡ EBMS — Electricity Board Management System
## Setup Guide (Node.js + MySQL)

---

## 📁 Project Structure
```
ebms-backend/
├── server.js        ← Express API server (all routes)
├── db.js            ← MySQL connection config
├── package.json     ← Dependencies
└── public/
    └── index.html   ← Frontend (served by Express)
```

---

## 🛠 Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

---

## 🗄 Step 2 — Set up MySQL Database
1. Open **MySQL Workbench** or your MySQL client
2. Create the database:
   ```sql
   CREATE DATABASE ebms;
   ```
3. Import the SQL file:
   ```
   mysql -u root -p ebms < ebms.sql
   ```
   OR use MySQL Workbench → Server → Data Import → import `ebms.sql`

---

## ⚙ Step 3 — Configure Database Password
Open `db.js` and update your credentials:
```js
const pool = mysql.createPool({
  host:     'localhost',
  user:     'root',        // ← Your MySQL username
  password: 'YOUR_PASSWORD_HERE',  // ← Your MySQL password
  database: 'ebms',
});
```

---

## 📦 Step 4 — Install Dependencies
Open terminal in the `ebms-backend` folder:
```bash
npm install
```

---

## 🚀 Step 5 — Start the Server
```bash
node server.js
```

You should see:
```
✅  MySQL connected successfully → database: ebms
⚡  EBMS Server running at http://localhost:3000
```

---

## 🌐 Step 6 — Open the App
Open your browser and go to:
```
http://localhost:3000
```

**Login credentials:**
- Admin:    `admin@ebms.in`   / `ebms@2024`
- Customer: `cust@ebms.in`    / `ebms@cust`

---

## 🔌 API Endpoints Reference

| Method | Endpoint              | Description            |
|--------|-----------------------|------------------------|
| GET    | /api/customers        | List all customers     |
| POST   | /api/customers        | Add customer           |
| PUT    | /api/customers/:id    | Update customer        |
| DELETE | /api/customers/:id    | Delete customer        |
| GET    | /api/accounts         | List all accounts      |
| POST   | /api/accounts         | Add account            |
| PUT    | /api/accounts/:id     | Update account         |
| DELETE | /api/accounts/:id     | Delete account         |
| GET    | /api/billing          | List all billing       |
| POST   | /api/billing          | Add billing record     |
| PUT    | /api/billing/:meter   | Update billing         |
| DELETE | /api/billing/:meter   | Delete billing         |
| GET    | /api/eboards          | List electricity boards|
| POST   | /api/eboards          | Add board              |
| DELETE | /api/eboards/:id      | Remove board           |
| GET    | /api/tariff           | List tariff types      |
| POST   | /api/tariff           | Add tariff             |
| DELETE | /api/tariff/:id       | Remove tariff          |
| GET    | /api/invoices         | List all invoices      |
| POST   | /api/invoices         | Generate invoice       |
| DELETE | /api/invoices/:id     | Delete invoice         |
| GET    | /api/admins           | List all admins        |
| POST   | /api/admins           | Add admin              |
| DELETE | /api/admins/:id       | Remove admin           |
| GET    | /api/dashboard        | Dashboard stats        |

---

## ❗ Troubleshooting

**"DB Offline" shown in header:**
- Make sure MySQL service is running
- Check username/password in `db.js`
- Verify database name is `ebms`

**Port 3000 already in use:**
Change the port in `server.js`:
```js
const PORT = 4000;  // change to any free port
```
Then update `API_BASE` in `public/index.html`:
```js
const API_BASE = 'http://localhost:4000/api';
```

**Foreign key errors when deleting:**
Delete records in this order: invoices → billing → accounts → customers
