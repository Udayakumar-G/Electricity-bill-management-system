// ─────────────────────────────────────────────
//  db.js  —  MySQL Connection Pool
// ─────────────────────────────────────────────
const mysql = require('mysql2');

const pool = mysql.createPool({
  host:     'localhost',   // Change if your DB is on a remote server
  user:     'root',        // Your MySQL username
  password: '',            // Your MySQL password
  database: 'ebms',        // Your database name
  port:     3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Test connection on startup
pool.getConnection((err, connection) => {
  if (err) {
    console.error('❌  MySQL connection failed:', err.message);
    console.error('   → Make sure MySQL is running and credentials in db.js are correct.');
  } else {
    console.log('✅  MySQL connected successfully → database: ebms');
    connection.release();
  }
});

module.exports = pool.promise();
