// ─────────────────────────────────────────────
//  server.js  —  EBMS Express API Server
// ─────────────────────────────────────────────
const express = require('express');
const cors    = require('cors');
const db      = require('./db');

const app  = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ══════════════════════════════════════════════
//  CUSTOMER AUTH  (Register / Login)
// ══════════════════════════════════════════════

app.post('/api/auth/register', async (req, res) => {
  const { cust_name, address, state, city, pincode, email, password } = req.body;
  if (!cust_name || !address || !state || !city || !pincode || !email || !password)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    const [existing] = await db.query('SELECT cust_id FROM customer_auth WHERE email = ?', [email]);
    if (existing.length)
      return res.status(409).json({ error: 'Email already registered' });

    const [[{ maxId }]] = await db.query('SELECT IFNULL(MAX(cust_id),500) AS maxId FROM customer');
    const newCustId = maxId + 1;

    const [[{ maxAccId }]] = await db.query('SELECT IFNULL(MAX(acc_id),430) AS maxAccId FROM account');
    const newAccId = maxAccId + 2;
    const account_no = String(Math.floor(10000 + Math.random() * 89999));

    await db.query(
      'INSERT INTO customer (cust_id, cust_name, address, state, city, pincode) VALUES (?,?,?,?,?,?)',
      [newCustId, cust_name, address, state, city, pincode]
    );
    await db.query(
      'INSERT INTO account (acc_id, cust_id, account_no, name) VALUES (?,?,?,?)',
      [newAccId, newCustId, account_no, cust_name]
    );
    await db.query(
      'INSERT INTO customer_auth (cust_id, email, password) VALUES (?,?,?)',
      [newCustId, email, password]
    );

    res.json({ success: true, message: 'Registration successful! You can now log in.', cust_id: newCustId, account_no });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/auth/customer-login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Email and password required' });
  try {
    const [rows] = await db.query(
      `SELECT ca.cust_id, ca.email, c.cust_name, c.address, c.state, c.city, c.pincode
       FROM customer_auth ca
       JOIN customer c ON ca.cust_id = c.cust_id
       WHERE ca.email = ? AND ca.password = ?`,
      [email, password]
    );
    if (!rows.length) return res.status(401).json({ error: 'Invalid email or password' });
    res.json({ success: true, customer: rows[0] });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  CUSTOMER SELF-SERVICE  (scoped by cust_id)
// ══════════════════════════════════════════════

app.get('/api/customer/:id/profile', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM customer WHERE cust_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/customer/:id/account', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM account WHERE cust_id = ?', [req.params.id]);
    res.json(rows[0] || null);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/customer/:id/billing', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT b.*, a.account_no FROM billing b
       LEFT JOIN account a ON b.acc_id = a.acc_id
       WHERE b.cust_id = ?`,
      [req.params.id]
    );
    res.json(rows[0] || null);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/customer/:id/invoices', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT i.*, e.board_name, t.tariff_type,
              b.monthly_units, b.amount_per_unit, b.total_amount
       FROM invoice i
       LEFT JOIN elec_board e ON i.eboard_id    = e.eboard_id
       LEFT JOIN tariff t     ON i.tariff_id    = t.tariff_id
       LEFT JOIN billing b    ON i.Meter_number = b.meter_number
       WHERE b.cust_id = ?
       ORDER BY i.reading_date DESC`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/customer/:id/pay', async (req, res) => {
  const { meter_number, amount_paid, payment_method } = req.body;
  if (!meter_number || !amount_paid)
    return res.status(400).json({ error: 'meter_number and amount_paid required' });
  try {
    await db.query(
      `INSERT INTO payment_history (cust_id, meter_number, amount_paid, payment_method, paid_at)
       VALUES (?,?,?,?,NOW())`,
      [req.params.id, meter_number, amount_paid, payment_method || 'Online']
    );
    res.json({ success: true, message: 'Payment recorded successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/customer/:id/payments', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT * FROM payment_history WHERE cust_id = ? ORDER BY paid_at DESC`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  CUSTOMERS  (Admin)
// ══════════════════════════════════════════════

app.get('/api/customers', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM customer ORDER BY cust_id');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/customers/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM customer WHERE cust_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Customer not found' });
    res.json(rows[0]);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/customers', async (req, res) => {
  const { cust_id, cust_name, address, state, city, pincode } = req.body;
  if (!cust_id || !cust_name || !address || !state || !city || !pincode)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query(
      'INSERT INTO customer (cust_id, cust_name, address, state, city, pincode) VALUES (?,?,?,?,?,?)',
      [cust_id, cust_name, address, state, city, pincode]
    );
    res.json({ success: true, message: 'Customer added successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/customers/:id', async (req, res) => {
  const { cust_name, address, state, city, pincode } = req.body;
  try {
    await db.query(
      'UPDATE customer SET cust_name=?, address=?, state=?, city=?, pincode=? WHERE cust_id=?',
      [cust_name, address, state, city, pincode, req.params.id]
    );
    res.json({ success: true, message: 'Customer updated successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/customers/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM customer WHERE cust_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Customer deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  ACCOUNTS  (Admin)
// ══════════════════════════════════════════════

app.get('/api/accounts', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT a.*, c.cust_name FROM account a LEFT JOIN customer c ON a.cust_id = c.cust_id ORDER BY a.acc_id'
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/accounts', async (req, res) => {
  const { acc_id, cust_id, account_no, name } = req.body;
  if (!acc_id || !cust_id || !account_no || !name)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query(
      'INSERT INTO account (acc_id, cust_id, account_no, name) VALUES (?,?,?,?)',
      [acc_id, cust_id, account_no, name]
    );
    res.json({ success: true, message: 'Account added successfully' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/accounts/:id', async (req, res) => {
  const { cust_id, account_no, name } = req.body;
  try {
    await db.query(
      'UPDATE account SET cust_id=?, account_no=?, name=? WHERE acc_id=?',
      [cust_id, account_no, name, req.params.id]
    );
    res.json({ success: true, message: 'Account updated' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/accounts/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM account WHERE acc_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Account deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  BILLING  (Admin)
// ══════════════════════════════════════════════

app.get('/api/billing', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT b.*, c.cust_name, a.account_no
       FROM billing b
       LEFT JOIN customer c ON b.cust_id = c.cust_id
       LEFT JOIN account a ON b.acc_id = a.acc_id
       ORDER BY b.meter_number`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/billing', async (req, res) => {
  const { meter_number, acc_id, cust_id, monthly_units, amount_per_unit, total_amount } = req.body;
  if (!meter_number || !acc_id || !cust_id || !monthly_units || !amount_per_unit)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    const total = total_amount || (monthly_units * amount_per_unit);
    await db.query(
      'INSERT INTO billing (meter_number, acc_id, cust_id, monthly_units, amount_per_unit, total_amount) VALUES (?,?,?,?,?,?)',
      [meter_number, acc_id, cust_id, monthly_units, amount_per_unit, total]
    );
    res.json({ success: true, message: 'Billing record added' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/api/billing/:meter', async (req, res) => {
  const { acc_id, cust_id, monthly_units, amount_per_unit, total_amount } = req.body;
  try {
    const total = total_amount || (monthly_units * amount_per_unit);
    await db.query(
      'UPDATE billing SET acc_id=?, cust_id=?, monthly_units=?, amount_per_unit=?, total_amount=? WHERE meter_number=?',
      [acc_id, cust_id, monthly_units, amount_per_unit, total, req.params.meter]
    );
    res.json({ success: true, message: 'Billing updated' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/billing/:meter', async (req, res) => {
  try {
    await db.query('DELETE FROM billing WHERE meter_number = ?', [req.params.meter]);
    res.json({ success: true, message: 'Billing record deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  ELECTRICITY BOARDS
// ══════════════════════════════════════════════

app.get('/api/eboards', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM elec_board ORDER BY eboard_id');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/eboards', async (req, res) => {
  const { eboard_id, board_name } = req.body;
  if (!eboard_id || !board_name)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query('INSERT INTO elec_board (eboard_id, board_name) VALUES (?,?)', [eboard_id, board_name]);
    res.json({ success: true, message: 'Board registered' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/eboards/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM elec_board WHERE eboard_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Board removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  TARIFF
// ══════════════════════════════════════════════

app.get('/api/tariff', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM tariff ORDER BY tariff_id');
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/tariff', async (req, res) => {
  const { tariff_id, tariff_type } = req.body;
  if (!tariff_id || !tariff_type)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query('INSERT INTO tariff (tariff_id, tariff_type) VALUES (?,?)', [tariff_id, tariff_type]);
    res.json({ success: true, message: 'Tariff added' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/tariff/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM tariff WHERE tariff_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Tariff removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  INVOICES  (Admin)
// ══════════════════════════════════════════════

app.get('/api/invoices', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT i.*, e.board_name, t.tariff_type,
              b.monthly_units, b.amount_per_unit, b.total_amount,
              c.cust_name, c.city, c.state, c.pincode
       FROM invoice i
       LEFT JOIN elec_board e  ON i.eboard_id   = e.eboard_id
       LEFT JOIN tariff t      ON i.tariff_id   = t.tariff_id
       LEFT JOIN billing b     ON i.Meter_number = b.meter_number
       LEFT JOIN customer c    ON b.cust_id      = c.cust_id
       ORDER BY i.invoice_id`
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/invoices', async (req, res) => {
  const { invoice_id, eboard_id, account_no, tariff_id, reading_date, Meter_number } = req.body;
  if (!invoice_id || !eboard_id || !account_no || !tariff_id || !reading_date || !Meter_number)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query(
      'INSERT INTO invoice (invoice_id, eboard_id, account_no, tariff_id, reading_date, Meter_number) VALUES (?,?,?,?,?,?)',
      [invoice_id, eboard_id, account_no, tariff_id, reading_date, Meter_number]
    );
    res.json({ success: true, message: 'Invoice generated' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/invoices/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM invoice WHERE invoice_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Invoice deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  ADMINS
// ══════════════════════════════════════════════

app.get('/api/admins', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT a.*, c.cust_name FROM admin a LEFT JOIN customer c ON a.cust_id = c.cust_id ORDER BY a.admin_id'
    );
    res.json(rows);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/admins', async (req, res) => {
  const { admin_id, admin_name, cust_id } = req.body;
  if (!admin_id || !admin_name || !cust_id)
    return res.status(400).json({ error: 'All fields are required' });
  try {
    await db.query('INSERT INTO admin (admin_id, admin_name, cust_id) VALUES (?,?,?)', [admin_id, admin_name, cust_id]);
    res.json({ success: true, message: 'Admin added' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/admins/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM admin WHERE admin_id = ?', [req.params.id]);
    res.json({ success: true, message: 'Admin removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  DASHBOARD STATS  (Admin overview)
// ══════════════════════════════════════════════

app.get('/api/dashboard', async (req, res) => {
  try {
    const [[custCount]]  = await db.query('SELECT COUNT(*) as total FROM customer');
    const [[meterCount]] = await db.query('SELECT COUNT(*) as total FROM billing');
    const [[boardCount]] = await db.query('SELECT COUNT(*) as total FROM elec_board');
    const [[revenue]]    = await db.query('SELECT IFNULL(SUM(total_amount),0) as total FROM billing');
    const [topConsumers] = await db.query(
      `SELECT c.cust_name, b.monthly_units, b.total_amount
       FROM billing b JOIN customer c ON b.cust_id = c.cust_id
       ORDER BY b.monthly_units DESC LIMIT 5`
    );
    const [byState] = await db.query(
      `SELECT c.state, COUNT(*) as cust_count, IFNULL(SUM(b.total_amount),0) as revenue
       FROM customer c LEFT JOIN billing b ON c.cust_id = b.cust_id
       GROUP BY c.state ORDER BY revenue DESC`
    );
    res.json({ customers: custCount.total, meters: meterCount.total, boards: boardCount.total,
               revenue: revenue.total, topConsumers, byState });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ══════════════════════════════════════════════
//  START SERVER
// ══════════════════════════════════════════════
app.listen(PORT, () => {
  console.log(`\n⚡  EBMS Server running at http://localhost:${PORT}`);
  console.log(`   → API ready at http://localhost:${PORT}/api/`);
  console.log(`   → Frontend at  http://localhost:${PORT}/\n`);
});
